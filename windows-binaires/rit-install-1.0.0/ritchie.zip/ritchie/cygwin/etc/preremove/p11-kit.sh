if [ -f /etc/pkcs11/pkcs11.conf ] && cmp -s /etc/defaults/etc/pkcs11/pkcs11.conf /etc/pkcs11/pkcs11.conf
then
    rm /etc/pkcs11/pkcs11.conf
fi

